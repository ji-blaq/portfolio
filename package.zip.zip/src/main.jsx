import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import { prefersReducedMotion } from "./utils/motion";

// Turn on scroll-reveal styles before the first paint (skipped for reduced motion).
if (!prefersReducedMotion()) {
  document.documentElement.classList.add("reveal-ready");
}

// A small hello for anyone curious enough to open DevTools.
console.log(
  "%cOAA.%c\nYou opened DevTools. Respect.\nFound a bug or a security issue on this site? Tell me: ajimatioluwatimilehinazeez@gmail.com",
  "font: 700 22px 'JetBrains Mono', monospace; color: #c98a3b;",
  "font: 12px 'JetBrains Mono', monospace; color: inherit;"
);

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>
);
