import "./App.css";

import Navbar from "./Components/Navbar";
import Hero from "./Components/Hero";
import Identity from "./Components/Identity";
import About from "./Components/About";
import Education from "./Components/Education";
import Journey from "./Components/Journey";
import Work from "./Components/Work";
import Contact from "./Components/Contact";
function App() {
  return (
    <div className="portfolio">
      <Navbar />

      <main>
        <Hero />
        <Identity />
        <About />
        <Education />
        <Journey />
        <Work />
        <Contact/>
      </main>
    </div>
  );
}

export default App;