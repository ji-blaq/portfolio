import { Code2, Palette, Braces, Atom } from "lucide-react";

function Journey() {
  const skills = [
    {
      icon: Code2,
      number: "01",
      name: "HTML",
      text: "Structure",
    },
    {
      icon: Palette,
      number: "02",
      name: "CSS",
      text: "Visual language",
    },
    {
      icon: Braces,
      number: "03",
      name: "JavaScript",
      text: "Interaction",
    },
    {
      icon: Atom,
      number: "04",
      name: "React",
      text: "Experience",
    },
  ];

  return (
    <section className="section journey-section" id="journey">
      <div className="section-label">JOURNEY</div>

      <div className="journey-heading">
        <h2>
          Learning the tools.
          <br />
          <span>Building the experience.</span>
        </h2>

        <p>
          Every technology changed the way I think about
          building for the web.
        </p>
      </div>

      <div className="skills-track">
        {skills.map((skill) => {
          const Icon = skill.icon;

          return (
            <div className="skill-card" key={skill.name}>
              <div className="skill-top">
                <span>{skill.number}</span>
                <Icon size={21} />
              </div>

              <h3>{skill.name}</h3>

              <p>{skill.text}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default Journey;