function About() {
  return (
    <section className="section about-section" id="about">
      <div className="section-label">ABOUT</div>

      <div className="about-grid">
        <div className="about-intro">
          <h2>
            I didn't start
            <br />
            <span>with code.</span>
          </h2>
        </div>

        <div className="about-copy">
          <p>
            My background is in Mass Communication, with a
            focus on PR and Advertising. Before I started
            building interfaces, I was already interested in
            how people receive information, what makes them
            pay attention, and why some messages work while
            others disappear.
          </p>

          <p>
            Frontend development became another way to explore
            that same curiosity — except now I get to build
            the thing people interact with.
          </p>

          <div className="about-facts">
            <div>
              <strong>01</strong>
              <span>Communication</span>
            </div>

            <div>
              <strong>02</strong>
              <span>Interface</span>
            </div>

            <div>
              <strong>03</strong>
              <span>Experience</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;