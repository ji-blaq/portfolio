function Identity() {
  return (
    <section className="section identity-section" id="identity">
      <div className="section-label">IDENTITY</div>

      <div className="identity-grid">
        <div>
          <h2>
            Two disciplines.
            <br />
            <span>One way of thinking.</span>
          </h2>
        </div>

        <div className="identity-world">
          <div className="orbit orbit-one">
            <span>PR</span>
          </div>

          <div className="orbit orbit-two">
            <span>UI</span>
          </div>

          <div className="identity-center">+</div>

          <p>
            Campaign thinking
            <br />
            meets product thinking.
          </p>
        </div>
      </div>
    </section>
  );
}

export default Identity;