import { ArrowDown, ArrowUpRight } from "lucide-react";
import profileImage from "../assets/profile.jpg";

function Hero() {
  return (
    <section className="hero" id="hero">
      <div className="hero-text">
        <div className="eyebrow">
          FRONTEND DEVELOPER <span>×</span> COMMUNICATION
        </div>

        <h1>
          Oluwatimilehin
          <br />
          <span>Azeez Ajimati</span>
        </h1>

        <p className="hero-copy">
          I build digital experiences with the mindset of a
          communicator — combining frontend engineering,
          storytelling, and visual thinking to make interfaces
          feel clear, useful, and human.
        </p>

        <div className="hero-actions">
          <button
            className="primary-button"
            onClick={() =>
              document
                .getElementById("projects")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            See my work
            <ArrowUpRight size={16} />
          </button>

          <button
            className="text-button"
            onClick={() =>
              document
                .getElementById("contact")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            Get in touch
          </button>
        </div>
      </div>

      <div className="hero-portrait">
        <div className="portrait-frame">
          <img src={profileImage} alt="Oluwatimilehin Ajimati" />

          <div className="portrait-label">
            <span>01</span>
            <span>BUILDING WITH INTENT</span>
          </div>
        </div>

        <div className="portrait-note">
          <span>SCROLL</span>
          <ArrowDown size={15} />
        </div>
      </div>
    </section>
  );
}

export default Hero;