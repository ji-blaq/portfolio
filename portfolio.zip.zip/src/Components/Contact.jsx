import {
  FaInstagram,
  FaLinkedinIn,
  FaXTwitter,
} from "react-icons/fa6";
import { Mail } from "lucide-react";

function Contact() {
  return (
    <section className="section contact-section" id="contact">
      <div className="section-label">CONTACT</div>

      <div className="contact-main">
        <div className="contact-heading">
          <h2>
            Let's build
            <br />
            <span>something useful.</span>
          </h2>
        </div>

        <div className="contact-right">
          <p>
            Have a project, idea, or opportunity that needs someone who
            thinks about both the interface and the message? Let's talk
            about it.
          </p>

          <a
            href="mailto:ajimatioluwatimilehinazeez@gmail.com"
            className="email-link"
          >
            <span>ajimatioluwatimilehinazeez@gmail.com</span>
            <span className="email-arrow">↗</span>
          </a>

          <div className="socials">
            <a
              href="https://www.instagram.com/ji_blaq0?igsi=bmxwaGNwdTdkcWJz&utm_source=qr"
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
            >
              <FaInstagram size={19} />
            </a>

            <a
              href="https://www.linkedin.com/in/oluwatimilehin-ajimati-b339633b6?utm_source=share_via&utm_content=profile&utm_medium=member_ios"
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
            >
              <FaLinkedinIn size={18} />
            </a>

            <a
              href="https://x.com/ji_blaq?s=11"
              target="_blank"
              rel="noreferrer"
              aria-label="X"
            >
              <FaXTwitter size={17} />
            </a>

            <a
              href="mailto:ajimatioluwatimilehinazeez@gmail.com"
              aria-label="Email"
            >
              <Mail size={19} />
            </a>
          </div>
        </div>
      </div>

      <footer>
        <span>OLUWATIMILEHIN AZEEZ AJIMATI</span>
        <span>FRONTEND × COMMUNICATION</span>
        <span>© 2026</span>
      </footer>
    </section>
  );
}

export default Contact;