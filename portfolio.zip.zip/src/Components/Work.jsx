import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, ExternalLink } from "lucide-react";

import homeImage from "../assets/home.png";
import productsImage from "../assets/products.png";
import productImage from "../assets/product.png";
import cartImage from "../assets/cart.png";
import checkoutImage from "../assets/checkout.png";

function Work() {
  const slides = [
    {
      image: homeImage,
      label: "01 / HOME",
    },
    {
      image: productsImage,
      label: "02 / PRODUCTS",
    },
    {
      image: productImage,
      label: "03 / PRODUCT",
    },
    {
      image: cartImage,
      label: "04 / CART",
    },
    {
      image: checkoutImage,
      label: "05 / CHECKOUT",
    },
  ];

  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 4000);

    return () => clearInterval(timer);
  }, [slides.length]);

  const previous = () => {
    setCurrent(
      (prev) => (prev - 1 + slides.length) % slides.length
    );
  };

  const next = () => {
    setCurrent((prev) => (prev + 1) % slides.length);
  };

  return (
    <section className="section work-section" id="projects">
      <div className="section-label">SELECTED WORK</div>

      <div className="work-heading">
        <div>
          <h2>
            420
            <br />
            <span>Collections.</span>
          </h2>
        </div>

        <div>
          <p>
            A fashion e-commerce experience built around
            product discovery, responsive layouts, and
            interactive shopping.
          </p>

          <div className="work-tags">
            <span>React</span>
            <span>JavaScript</span>
            <span>CSS</span>
            <span>API</span>
          </div>
        </div>
      </div>

      <div className="project-showcase">
        <div className="project-image">
          <img
            src={slides[current].image}
            alt={`420 Collections ${slides[current].label}`}
          />
        </div>

        <div className="project-controls">
          <span>{slides[current].label}</span>

          <div className="slider-buttons">
            <button onClick={previous} aria-label="Previous">
              <ArrowLeft size={17} />
            </button>

            <button onClick={next} aria-label="Next">
              <ArrowRight size={17} />
            </button>
          </div>
        </div>

        <div className="project-progress">
          {slides.map((_, index) => (
            <button
              key={index}
              className={
                index === current ? "active" : ""
              }
              onClick={() => setCurrent(index)}
              aria-label={`View slide ${index + 1}`}
            />
          ))}
        </div>
      </div>

      <div className="project-bottom">
        <span>ECOMMERCE / FRONTEND</span>

        <a href="https://420-collections.vercel.app/" target="_blank" rel="noreferrer">
          View project
          <ExternalLink size={15} />
        </a>
      </div>
    </section>
  );
}

export default Work;